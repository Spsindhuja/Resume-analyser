import React, { useState } from 'react';
import { ExternalLink, Clock, Star, Award, Bell, Play, CheckCircle } from 'lucide-react';

interface SkillPlatform {
  name: string;
  url: string;
  duration: string;
  rating: number;
  level: string;
  price: string;
  provider: string;
}

interface SkillLearningPlatformsProps {
  skill: string;
  onStartLearning: (skill: string, platform: string) => void;
}

export const SkillLearningPlatforms: React.FC<SkillLearningPlatformsProps> = ({ 
  skill, 
  onStartLearning 
}) => {
  const [enrolledCourses, setEnrolledCourses] = useState<Set<string>>(new Set());

  const getSkillPlatforms = (skill: string): SkillPlatform[] => {
    const platformsMap: Record<string, SkillPlatform[]> = {
      'Cloud Computing (AWS/Azure)': [
        {
          name: 'AWS Cloud Practitioner Essentials',
          url: 'https://aws.amazon.com/training/digital/aws-cloud-practitioner-essentials/',
          duration: '6 hours',
          rating: 4.8,
          level: 'Beginner',
          price: 'Free',
          provider: 'AWS Training'
        },
        {
          name: 'Microsoft Azure Fundamentals',
          url: 'https://docs.microsoft.com/en-us/learn/paths/azure-fundamentals/',
          duration: '10 hours',
          rating: 4.7,
          level: 'Beginner',
          price: 'Free',
          provider: 'Microsoft Learn'
        },
        {
          name: 'Cloud Computing Basics',
          url: 'https://www.coursera.org/learn/cloud-computing-basics',
          duration: '4 weeks',
          rating: 4.6,
          level: 'Beginner',
          price: 'Free Audit',
          provider: 'Coursera'
        }
      ],
      'Docker/Kubernetes': [
        {
          name: 'Docker for Beginners',
          url: 'https://www.docker.com/101-tutorial',
          duration: '2 hours',
          rating: 4.9,
          level: 'Beginner',
          price: 'Free',
          provider: 'Docker'
        },
        {
          name: 'Kubernetes Basics',
          url: 'https://kubernetes.io/docs/tutorials/kubernetes-basics/',
          duration: '4 hours',
          rating: 4.8,
          level: 'Intermediate',
          price: 'Free',
          provider: 'Kubernetes.io'
        },
        {
          name: 'Container Orchestration',
          url: 'https://unstop.com/courses/container-orchestration',
          duration: '3 weeks',
          rating: 4.5,
          level: 'Intermediate',
          price: 'Free',
          provider: 'Unstop'
        }
      ],
      'GraphQL': [
        {
          name: 'GraphQL Fundamentals',
          url: 'https://graphql.org/learn/',
          duration: '3 hours',
          rating: 4.7,
          level: 'Beginner',
          price: 'Free',
          provider: 'GraphQL.org'
        },
        {
          name: 'Full Stack GraphQL',
          url: 'https://www.howtographql.com/',
          duration: '8 hours',
          rating: 4.8,
          level: 'Intermediate',
          price: 'Free',
          provider: 'How to GraphQL'
        },
        {
          name: 'GraphQL with React',
          url: 'https://www.freecodecamp.org/news/graphql-react-tutorial/',
          duration: '5 hours',
          rating: 4.6,
          level: 'Intermediate',
          price: 'Free',
          provider: 'FreeCodeCamp'
        }
      ],
      'Testing Frameworks': [
        {
          name: 'Jest Testing Framework',
          url: 'https://jestjs.io/docs/tutorial-react',
          duration: '4 hours',
          rating: 4.8,
          level: 'Beginner',
          price: 'Free',
          provider: 'Jest'
        },
        {
          name: 'React Testing Library',
          url: 'https://testing-library.com/docs/react-testing-library/intro/',
          duration: '3 hours',
          rating: 4.9,
          level: 'Intermediate',
          price: 'Free',
          provider: 'Testing Library'
        },
        {
          name: 'Complete Testing Course',
          url: 'https://unstop.com/courses/software-testing',
          duration: '6 weeks',
          rating: 4.5,
          level: 'Beginner',
          price: 'Free',
          provider: 'Unstop'
        }
      ]
    };

    return platformsMap[skill] || [
      {
        name: `${skill} Fundamentals`,
        url: `https://www.google.com/search?q=${encodeURIComponent(skill + ' tutorial')}`,
        duration: '4 hours',
        rating: 4.5,
        level: 'Beginner',
        price: 'Free',
        provider: 'Google Search'
      }
    ];
  };

  const platforms = getSkillPlatforms(skill);

  const handleEnroll = (platform: SkillPlatform) => {
    setEnrolledCourses(prev => new Set([...prev, platform.name]));
    onStartLearning(skill, platform.name);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-lg font-semibold text-gray-800">
          Learning Resources for {skill}
        </h4>
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Bell className="w-4 h-4" />
          <span>Daily progress notifications enabled</span>
        </div>
      </div>

      {platforms.map((platform, index) => (
        <div key={index} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-3">
            <div className="flex-1">
              <h5 className="font-semibold text-gray-800 mb-1">{platform.name}</h5>
              <p className="text-sm text-blue-600 font-medium">{platform.provider}</p>
            </div>
            <div className="flex items-center space-x-1 text-yellow-500">
              <Star className="w-4 h-4 fill-current" />
              <span className="text-sm font-medium">{platform.rating}</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-4 text-sm text-gray-600">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span>{platform.duration}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Award className="w-4 h-4" />
              <span>{platform.level}</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="font-medium text-green-600">{platform.price}</span>
            </div>
          </div>

          <div className="flex space-x-3">
            {enrolledCourses.has(platform.name) ? (
              <div className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg">
                <CheckCircle className="w-4 h-4" />
                <span>Enrolled</span>
              </div>
            ) : (
              <button
                onClick={() => handleEnroll(platform)}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
              >
                <Play className="w-4 h-4" />
                <span>Start Learning</span>
              </button>
            )}
            <a
              href={platform.url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2"
            >
              <ExternalLink className="w-4 h-4" />
              <span>View</span>
            </a>
          </div>
        </div>
      ))}
    </div>
  );
};