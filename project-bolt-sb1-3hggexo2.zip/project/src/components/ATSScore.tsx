import React from 'react';
import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

interface ATSScoreProps {
  score: number;
  breakdown: {
    keywords: number;
    formatting: number;
    experience: number;
    skills: number;
  };
}

export const ATSScore: React.FC<ATSScoreProps> = ({ score, breakdown }) => {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="w-6 h-6 text-green-600" />;
    if (score >= 60) return <AlertTriangle className="w-6 h-6 text-yellow-600" />;
    return <XCircle className="w-6 h-6 text-red-600" />;
  };

  const getScoreMessage = (score: number) => {
    if (score >= 80) return 'Excellent! Your resume is ATS-friendly';
    if (score >= 60) return 'Good, but room for improvement';
    return 'Needs significant improvement';
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="text-center mb-6">
        <div className="flex items-center justify-center mb-2">
          {getScoreIcon(score)}
        </div>
        <h3 className="text-2xl font-bold mb-2">ATS Score</h3>
        <div className={`text-4xl font-bold ${getScoreColor(score)}`}>
          {score}/100
        </div>
        <p className="text-gray-600 mt-2">{getScoreMessage(score)}</p>
      </div>

      <div className="space-y-4">
        <h4 className="font-semibold text-gray-800 mb-3">Score Breakdown</h4>
        
        {Object.entries(breakdown).map(([key, value]) => (
          <div key={key} className="flex items-center justify-between">
            <span className="capitalize text-gray-700">{key}</span>
            <div className="flex items-center space-x-2">
              <div className="w-24 bg-gray-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full ${
                    value >= 80 ? 'bg-green-500' : value >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${value}%` }}
                ></div>
              </div>
              <span className="text-sm font-medium text-gray-600 w-8">{value}%</span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h5 className="font-semibold text-blue-800 mb-2">Quick Tips</h5>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• Use relevant keywords from job descriptions</li>
          <li>• Keep formatting simple and clean</li>
          <li>• Quantify your achievements with numbers</li>
          <li>• Include relevant skills and certifications</li>
        </ul>
      </div>
    </div>
  );
};