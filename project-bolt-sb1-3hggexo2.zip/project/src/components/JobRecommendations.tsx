import React from 'react';
import { MapPin, DollarSign, Clock, ExternalLink, Star, Briefcase } from 'lucide-react';

export const JobRecommendations: React.FC = () => {
  const jobs = [
    {
      id: 1,
      title: 'Senior Frontend Developer',
      company: 'TechCorp Inc.',
      location: 'San Francisco, CA',
      salary: '$120,000 - $150,000',
      type: 'Full-time',
      match: 92,
      posted: '2 days ago',
      skills: ['React', 'TypeScript', 'Node.js', 'AWS'],
      description: 'Join our dynamic team building next-generation web applications...',
      applyLinks: [
        { platform: 'Unstop', url: 'https://unstop.com/jobs/senior-frontend-developer' },
        { platform: 'LinkedIn', url: 'https://linkedin.com/jobs/view/senior-frontend-developer' },
        { platform: 'Indeed', url: 'https://indeed.com/viewjob?jk=senior-frontend-developer' }
      ]
    },
    {
      id: 2,
      title: 'Full Stack Developer',
      company: 'StartupXYZ',
      location: 'Remote',
      salary: '$90,000 - $130,000',
      type: 'Full-time',
      match: 87,
      posted: '1 week ago',
      skills: ['JavaScript', 'React', 'Python', 'PostgreSQL'],
      description: 'We are looking for a passionate full stack developer to help us scale...',
      applyLinks: [
        { platform: 'Unstop', url: 'https://unstop.com/jobs/full-stack-developer' },
        { platform: 'AngelList', url: 'https://angel.co/jobs/full-stack-developer' },
        { platform: 'Glassdoor', url: 'https://glassdoor.com/job/full-stack-developer' }
      ]
    },
    {
      id: 3,
      title: 'React Developer',
      company: 'Digital Solutions Ltd.',
      location: 'New York, NY',
      salary: '$85,000 - $110,000',
      type: 'Contract',
      match: 82,
      posted: '3 days ago',
      skills: ['React', 'Redux', 'JavaScript', 'CSS'],
      description: 'Exciting opportunity to work on cutting-edge React applications...',
      applyLinks: [
        { platform: 'Unstop', url: 'https://unstop.com/jobs/react-developer' },
        { platform: 'Stack Overflow Jobs', url: 'https://stackoverflow.com/jobs/react-developer' },
        { platform: 'Dice', url: 'https://dice.com/jobs/react-developer' }
      ]
    },
    {
      id: 4,
      title: 'Frontend Engineer',
      company: 'InnovateNow',
      location: 'Austin, TX',
      salary: '$100,000 - $135,000',
      type: 'Full-time',
      match: 78,
      posted: '5 days ago',
      skills: ['Vue.js', 'JavaScript', 'HTML/CSS', 'Git'],
      description: 'Be part of our mission to revolutionize user experiences...',
      applyLinks: [
        { platform: 'Unstop', url: 'https://unstop.com/jobs/frontend-engineer' },
        { platform: 'ZipRecruiter', url: 'https://ziprecruiter.com/jobs/frontend-engineer' },
        { platform: 'Monster', url: 'https://monster.com/jobs/frontend-engineer' }
      ]
    }
  ];

  const getMatchColor = (match: number) => {
    if (match >= 90) return 'text-green-600 bg-green-100';
    if (match >= 80) return 'text-blue-600 bg-blue-100';
    return 'text-yellow-600 bg-yellow-100';
  };

  const getPlatformColor = (platform: string) => {
    const colors: Record<string, string> = {
      'Unstop': 'bg-purple-600 hover:bg-purple-700',
      'LinkedIn': 'bg-blue-700 hover:bg-blue-800',
      'Indeed': 'bg-blue-600 hover:bg-blue-700',
      'AngelList': 'bg-black hover:bg-gray-800',
      'Glassdoor': 'bg-green-600 hover:bg-green-700',
      'Stack Overflow Jobs': 'bg-orange-500 hover:bg-orange-600',
      'Dice': 'bg-blue-500 hover:bg-blue-600',
      'ZipRecruiter': 'bg-red-600 hover:bg-red-700',
      'Monster': 'bg-purple-700 hover:bg-purple-800'
    };
    return colors[platform] || 'bg-gray-600 hover:bg-gray-700';
  };

  return (
    <div className="space-y-4">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">Recommended Jobs</h3>
        <p className="text-gray-600">Based on your resume analysis and skills</p>
      </div>

      {jobs.map((job) => (
        <div key={job.id} className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-200">
          <div className="flex justify-between items-start mb-4">
            <div className="flex-1">
              <h4 className="text-lg font-bold text-gray-800 mb-1">{job.title}</h4>
              <p className="text-blue-600 font-medium">{job.company}</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${getMatchColor(job.match)}`}>
              <div className="flex items-center space-x-1">
                <Star className="w-3 h-3" />
                <span>{job.match}% match</span>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mb-4 text-sm text-gray-600">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4" />
              <span>{job.location}</span>
            </div>
            <div className="flex items-center space-x-2">
              <DollarSign className="w-4 h-4" />
              <span>{job.salary}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span>{job.type} • {job.posted}</span>
            </div>
          </div>

          <p className="text-gray-700 mb-4">{job.description}</p>

          <div className="flex flex-wrap gap-2 mb-4">
            {job.skills.map((skill, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-sm"
              >
                {skill}
              </span>
            ))}
          </div>

          {/* Apply Links */}
          <div className="border-t pt-4">
            <h5 className="text-sm font-semibold text-gray-700 mb-3 flex items-center">
              <Briefcase className="w-4 h-4 mr-2" />
              Apply on Multiple Platforms
            </h5>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              {job.applyLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`px-4 py-2 text-white rounded-lg transition-colors flex items-center justify-center space-x-2 text-sm ${getPlatformColor(link.platform)}`}
                >
                  <ExternalLink className="w-3 h-3" />
                  <span>{link.platform}</span>
                </a>
              ))}
            </div>
          </div>

          <div className="flex space-x-3 mt-4">
            <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              Save Job
            </button>
            <button className="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors">
              Set Alert
            </button>
          </div>
        </div>
      ))}

      <div className="text-center py-8">
        <button className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200">
          Load More Jobs
        </button>
      </div>
    </div>
  );
};