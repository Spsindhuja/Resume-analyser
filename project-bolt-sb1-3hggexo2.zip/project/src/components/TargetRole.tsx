import React, { useState } from 'react';
import { Search, Star, Zap, BookOpen, MessageCircle, TrendingUp } from 'lucide-react';
import { SkillLearningPlatforms } from './SkillLearningPlatforms';
import { LearningProgress } from './LearningProgress';
import { AITeacher } from './AITeacher';

interface TargetRoleProps {
  onRoleAnalysis: (role: string) => void;
}

export const TargetRole: React.FC<TargetRoleProps> = ({ onRoleAnalysis }) => {
  const [role, setRole] = useState('');
  const [analysis, setAnalysis] = useState<any>(null);
  const [showSkillsModal, setShowSkillsModal] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'platforms' | 'progress' | 'ai-teacher'>('platforms');
  const [enrolledCourses, setEnrolledCourses] = useState<Array<{
    skill: string;
    platform: string;
    startDate: Date;
    estimatedDuration: number;
  }>>([]);

  const handleAnalyze = () => {
    if (role.trim()) {
      // Mock analysis data
      const mockAnalysis = {
        role: role,
        matchScore: Math.floor(Math.random() * 40) + 60,
        requiredSkills: [
          'JavaScript/TypeScript',
          'React/Vue/Angular',
          'Node.js',
          'Database Management',
          'API Development',
          'Git Version Control',
          'Agile Methodology',
          'Problem Solving'
        ],
        missingSkills: [
          'Cloud Computing (AWS/Azure)',
          'Docker/Kubernetes',
          'GraphQL',
          'Testing Frameworks'
        ],
        salaryRange: '$75,000 - $120,000',
        experienceLevel: 'Mid-level (3-5 years)'
      };
      setAnalysis(mockAnalysis);
      onRoleAnalysis(role);
    }
  };

  const handleStartLearning = (skill: string, platform: string) => {
    const newCourse = {
      skill,
      platform,
      startDate: new Date(),
      estimatedDuration: Math.floor(Math.random() * 30) + 14 // 14-44 days
    };
    setEnrolledCourses(prev => [...prev, newCourse]);
    setActiveTab('progress');
  };

  const handleSkillImprovement = (skill: string, improvement: number) => {
    // This would update the user's skill scores in a real application
    console.log(`${skill} improved by ${improvement} points`);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Target Role Analysis</h3>
        
        <div className="flex space-x-3">
          <input
            type="text"
            value={role}
            onChange={(e) => setRole(e.target.value)}
            placeholder="e.g., Frontend Developer, Data Scientist, Product Manager"
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            onClick={handleAnalyze}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Search className="w-4 h-4" />
            <span>Analyze</span>
          </button>
        </div>
      </div>

      {analysis && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h4 className="text-lg font-bold text-gray-800">{analysis.role}</h4>
              <p className="text-gray-600">{analysis.experienceLevel}</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">{analysis.matchScore}%</div>
              <div className="text-sm text-gray-500">Match Score</div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h5 className="font-semibold text-green-700 mb-3 flex items-center">
                <Star className="w-4 h-4 mr-2" />
                Skills You Have
              </h5>
              <div className="space-y-2">
                {analysis.requiredSkills.map((skill: string, index: number) => (
                  <div key={index} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-700">{skill}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h5 className="font-semibold text-red-700 mb-3 flex items-center">
                <Zap className="w-4 h-4 mr-2" />
                Skills to Develop
              </h5>
              <div className="space-y-2">
                {analysis.missingSkills.map((skill: string, index: number) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span className="text-sm text-gray-700">{skill}</span>
                    </div>
                    <button
                      onClick={() => {
                        setSelectedSkill(skill);
                        setShowSkillsModal(true);
                      }}
                      className="text-xs text-blue-600 hover:text-blue-800 underline"
                    >
                      Learn
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium text-gray-700">Salary Range:</span>
              <span className="text-blue-600 font-semibold">{analysis.salaryRange}</span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mt-4">
            <button
              onClick={() => setShowSkillsModal(true)}
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center justify-center space-x-2"
            >
              <BookOpen className="w-4 h-4" />
              <span>Get Skills Development Plan</span>
            </button>
            
            <button
              onClick={() => {
                setShowSkillsModal(true);
                setActiveTab('ai-teacher');
              }}
              className="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200 flex items-center justify-center space-x-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>AI Communication Coach</span>
            </button>
          </div>
        </div>
      )}

      {showSkillsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-gray-800">Skills Development Center</h3>
                <button
                  onClick={() => setShowSkillsModal(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>

              {/* Tab Navigation */}
              <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg">
                <button
                  onClick={() => setActiveTab('platforms')}
                  className={`flex-1 flex items-center justify-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                    activeTab === 'platforms'
                      ? 'bg-white shadow-sm text-blue-600'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Learning Platforms</span>
                </button>
                <button
                  onClick={() => setActiveTab('progress')}
                  className={`flex-1 flex items-center justify-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                    activeTab === 'progress'
                      ? 'bg-white shadow-sm text-blue-600'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>Progress Tracking</span>
                </button>
                <button
                  onClick={() => setActiveTab('ai-teacher')}
                  className={`flex-1 flex items-center justify-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                    activeTab === 'ai-teacher'
                      ? 'bg-white shadow-sm text-blue-600'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>AI Coach</span>
                </button>
              </div>

              {/* Tab Content */}
              <div className="min-h-[500px]">
                {activeTab === 'platforms' && selectedSkill && (
                  <SkillLearningPlatforms 
                    skill={selectedSkill} 
                    onStartLearning={handleStartLearning}
                  />
                )}
                
                {activeTab === 'progress' && (
                  <LearningProgress enrolledCourses={enrolledCourses} />
                )}
                
                {activeTab === 'ai-teacher' && (
                  <AITeacher onSkillImprovement={handleSkillImprovement} />
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};