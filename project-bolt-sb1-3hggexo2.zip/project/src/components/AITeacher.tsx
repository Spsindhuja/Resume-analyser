import React, { useState, useEffect } from 'react';
import { MessageCircle, Mic, MicOff, Volume2, Award, Star, Send } from 'lucide-react';

interface AITeacherProps {
  onSkillImprovement: (skill: string, improvement: number) => void;
}

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type?: 'lesson' | 'feedback' | 'assessment';
}

export const AITeacher: React.FC<AITeacherProps> = ({ onSkillImprovement }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [currentLesson, setCurrentLesson] = useState(0);
  const [communicationScore, setCommunicationScore] = useState(65);
  const [isAssessmentMode, setIsAssessmentMode] = useState(false);

  const lessons = [
    {
      title: "Professional Email Communication",
      content: "Let's practice writing professional emails. I'll give you a scenario and you respond appropriately.",
      scenario: "You need to request a deadline extension for a project. Write a professional email to your manager."
    },
    {
      title: "Active Listening Skills",
      content: "Active listening is crucial for effective communication. Let's practice with a role-play scenario.",
      scenario: "I'm a frustrated client. Listen to my concerns and respond empathetically."
    },
    {
      title: "Presentation Skills",
      content: "Practice presenting complex ideas clearly and concisely.",
      scenario: "Explain a technical concept to a non-technical audience in 2 minutes."
    },
    {
      title: "Conflict Resolution",
      content: "Learn to handle workplace conflicts professionally.",
      scenario: "Two team members disagree on project approach. How would you mediate?"
    }
  ];

  useEffect(() => {
    // Initialize with welcome message
    const welcomeMessage: Message = {
      id: '1',
      text: "Hello! I'm your AI Communication Coach. I'm here to help you improve your communication skills through interactive lessons and real-time feedback. Ready to start?",
      sender: 'ai',
      timestamp: new Date(),
      type: 'lesson'
    };
    setMessages([welcomeMessage]);
  }, []);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(inputText);
      setMessages(prev => [...prev, aiResponse]);
    }, 1000);
  };

  const generateAIResponse = (userInput: string): Message => {
    const responses = [
      "Great communication! I noticed you used clear, professional language. Your score improved by 5 points!",
      "Good effort! Try to be more concise next time. Here's how you could improve...",
      "Excellent active listening! You acknowledged the concern and provided a thoughtful response.",
      "I can see improvement in your tone. Let's work on structuring your message more effectively."
    ];

    // Simulate score improvement
    const improvement = Math.floor(Math.random() * 10) + 1;
    setCommunicationScore(prev => Math.min(prev + improvement, 100));
    onSkillImprovement('Communication', improvement);

    return {
      id: Date.now().toString(),
      text: responses[Math.floor(Math.random() * responses.length)],
      sender: 'ai',
      timestamp: new Date(),
      type: 'feedback'
    };
  };

  const startLesson = (lessonIndex: number) => {
    setCurrentLesson(lessonIndex);
    const lesson = lessons[lessonIndex];
    
    const lessonMessage: Message = {
      id: Date.now().toString(),
      text: `${lesson.title}\n\n${lesson.content}\n\nScenario: ${lesson.scenario}`,
      sender: 'ai',
      timestamp: new Date(),
      type: 'lesson'
    };

    setMessages(prev => [...prev, lessonMessage]);
  };

  const startAssessment = () => {
    setIsAssessmentMode(true);
    const assessmentMessage: Message = {
      id: Date.now().toString(),
      text: "Let's do a quick communication assessment! I'll ask you 3 questions. Answer naturally and I'll provide detailed feedback.",
      sender: 'ai',
      timestamp: new Date(),
      type: 'assessment'
    };
    setMessages(prev => [...prev, assessmentMessage]);
  };

  const generateCertificate = () => {
    if (communicationScore >= 85) {
      alert('🎉 Congratulations! Your Communication Skills Certificate is ready for download!');
    } else {
      alert(`Keep practicing! You need ${85 - communicationScore} more points to earn your certificate.`);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 h-[600px] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-4 border-b">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
            <MessageCircle className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">AI Communication Coach</h3>
            <p className="text-sm text-gray-600">Improve your soft skills</p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold text-purple-600">{communicationScore}/100</div>
          <div className="text-xs text-gray-500">Communication Score</div>
        </div>
      </div>

      {/* Lesson Selection */}
      <div className="mb-4">
        <div className="flex flex-wrap gap-2 mb-3">
          {lessons.map((lesson, index) => (
            <button
              key={index}
              onClick={() => startLesson(index)}
              className="px-3 py-1 text-xs bg-purple-100 text-purple-700 rounded-full hover:bg-purple-200 transition-colors"
            >
              {lesson.title}
            </button>
          ))}
          <button
            onClick={startAssessment}
            className="px-3 py-1 text-xs bg-green-100 text-green-700 rounded-full hover:bg-green-200 transition-colors"
          >
            Assessment
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-3 mb-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] p-3 rounded-lg ${
                message.sender === 'user'
                  ? 'bg-blue-600 text-white'
                  : message.type === 'lesson'
                  ? 'bg-purple-50 text-purple-800 border border-purple-200'
                  : message.type === 'assessment'
                  ? 'bg-green-50 text-green-800 border border-green-200'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              <p className="text-sm whitespace-pre-line">{message.text}</p>
              <span className="text-xs opacity-70 mt-1 block">
                {message.timestamp.toLocaleTimeString()}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Input Area */}
      <div className="border-t pt-4">
        <div className="flex items-center space-x-2 mb-3">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Type your response..."
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
          <button
            onClick={handleSendMessage}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

        <div className="flex justify-between items-center">
          <div className="flex space-x-2">
            <button
              onClick={() => setIsListening(!isListening)}
              className={`p-2 rounded-lg transition-colors ${
                isListening ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-600'
              }`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
            <button className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">
              <Volume2 className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={generateCertificate}
            className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200"
          >
            <Award className="w-4 h-4" />
            <span>Get Certificate</span>
          </button>
        </div>
      </div>
    </div>
  );
};