import React, { useState, useEffect } from 'react';
import { Clock, TrendingUp, Award, Bell, Calendar, Target } from 'lucide-react';
import { format, addDays, differenceInDays } from 'date-fns';

interface LearningProgressProps {
  enrolledCourses: Array<{
    skill: string;
    platform: string;
    startDate: Date;
    estimatedDuration: number; // in days
  }>;
}

interface ProgressData {
  skill: string;
  platform: string;
  progress: number;
  dailyTarget: number;
  completedDays: number;
  totalDays: number;
  nextMilestone: string;
  lastNotification: Date;
}

export const LearningProgress: React.FC<LearningProgressProps> = ({ enrolledCourses }) => {
  const [progressData, setProgressData] = useState<ProgressData[]>([]);
  const [notifications, setNotifications] = useState<string[]>([]);

  useEffect(() => {
    // Initialize progress data for enrolled courses
    const initialProgress = enrolledCourses.map(course => {
      const daysSinceStart = differenceInDays(new Date(), course.startDate);
      const progress = Math.min((daysSinceStart / course.estimatedDuration) * 100, 100);
      
      return {
        skill: course.skill,
        platform: course.platform,
        progress: Math.max(progress, Math.random() * 30 + 10), // Simulate some progress
        dailyTarget: 100 / course.estimatedDuration,
        completedDays: Math.max(daysSinceStart, 0),
        totalDays: course.estimatedDuration,
        nextMilestone: getNextMilestone(progress),
        lastNotification: new Date()
      };
    });

    setProgressData(initialProgress);

    // Simulate daily notifications
    const notificationInterval = setInterval(() => {
      const newNotifications = generateDailyNotifications(initialProgress);
      setNotifications(prev => [...newNotifications, ...prev].slice(0, 10));
    }, 5000); // Every 5 seconds for demo (would be daily in production)

    return () => clearInterval(notificationInterval);
  }, [enrolledCourses]);

  const getNextMilestone = (progress: number): string => {
    if (progress < 25) return '25% - Foundation Complete';
    if (progress < 50) return '50% - Halfway There!';
    if (progress < 75) return '75% - Almost Done!';
    if (progress < 100) return '100% - Course Complete!';
    return 'Certificate Ready!';
  };

  const generateDailyNotifications = (progressData: ProgressData[]): string[] => {
    const notifications = [];
    const currentTime = format(new Date(), 'HH:mm');
    
    for (const course of progressData) {
      if (course.progress < 100) {
        notifications.push(
          `🎯 ${currentTime} - Time for your ${course.skill} lesson! You're ${course.progress.toFixed(0)}% complete.`
        );
        
        if (Math.random() > 0.5) {
          notifications.push(
            `🔥 ${currentTime} - Great progress on ${course.platform}! Keep up the momentum.`
          );
        }
      }
    }
    
    return notifications;
  };

  const getProgressColor = (progress: number): string => {
    if (progress >= 75) return 'bg-green-500';
    if (progress >= 50) return 'bg-blue-500';
    if (progress >= 25) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      {/* Notifications Panel */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center">
            <Bell className="w-5 h-5 mr-2 text-blue-600" />
            Learning Notifications
          </h3>
          <span className="text-sm text-gray-500">Updated every 12 hours</span>
        </div>
        
        <div className="max-h-40 overflow-y-auto space-y-2">
          {notifications.length > 0 ? (
            notifications.map((notification, index) => (
              <div key={index} className="p-3 bg-blue-50 rounded-lg text-sm text-gray-700 border-l-4 border-blue-500">
                {notification}
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-center py-4">No notifications yet. Start learning to receive updates!</p>
          )}
        </div>
      </div>

      {/* Progress Cards */}
      <div className="grid gap-6">
        {progressData.map((course, index) => (
          <div key={index} className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h4 className="text-lg font-semibold text-gray-800">{course.skill}</h4>
                <p className="text-sm text-gray-600">{course.platform}</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-blue-600">{course.progress.toFixed(0)}%</div>
                <div className="text-sm text-gray-500">Complete</div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Progress</span>
                <span>{course.nextMilestone}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-500 ${getProgressColor(course.progress)}`}
                  style={{ width: `${course.progress}%` }}
                ></div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-3 bg-gray-50 rounded-lg">
                <Calendar className="w-5 h-5 mx-auto mb-1 text-gray-600" />
                <div className="text-sm font-medium text-gray-800">{course.completedDays}</div>
                <div className="text-xs text-gray-500">Days Active</div>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <Target className="w-5 h-5 mx-auto mb-1 text-gray-600" />
                <div className="text-sm font-medium text-gray-800">{course.dailyTarget.toFixed(1)}%</div>
                <div className="text-xs text-gray-500">Daily Target</div>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <TrendingUp className="w-5 h-5 mx-auto mb-1 text-gray-600" />
                <div className="text-sm font-medium text-gray-800">{course.totalDays - course.completedDays}</div>
                <div className="text-xs text-gray-500">Days Left</div>
              </div>
            </div>

            {/* Action Button */}
            {course.progress >= 100 && (
              <button className="w-full mt-4 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2">
                <Award className="w-4 h-4" />
                <span>Generate Certificate</span>
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};