import React, { useState } from 'react';
import { Target, Briefcase } from 'lucide-react';
import { TargetRole } from './TargetRole';
import { JobRecommendations } from './JobRecommendations';

interface ResultsTabsProps {
  onRoleAnalysis: (role: string) => void;
}

export const ResultsTabs: React.FC<ResultsTabsProps> = ({ onRoleAnalysis }) => {
  const [activeTab, setActiveTab] = useState<'target' | 'jobs'>('target');

  const tabs = [
    { id: 'target', label: 'Target Role', icon: Target },
    { id: 'jobs', label: 'Job Recommendations', icon: Briefcase }
  ];

  return (
    <div className="w-full">
      <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as 'target' | 'jobs')}
              className={`flex-1 flex items-center justify-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-white shadow-sm text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>

      <div className="min-h-[400px]">
        {activeTab === 'target' && <TargetRole onRoleAnalysis={onRoleAnalysis} />}
        {activeTab === 'jobs' && <JobRecommendations />}
      </div>
    </div>
  );
};