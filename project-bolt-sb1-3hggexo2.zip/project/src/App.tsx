import React, { useState } from 'react';
import { FileUpload } from './components/FileUpload';
import { ATSScore } from './components/ATSScore';
import { ResultsTabs } from './components/ResultsTabs';
import { FileText, Sparkles } from 'lucide-react';

interface AnalysisResults {
  score: number;
  breakdown: {
    keywords: number;
    formatting: number;
    experience: number;
    skills: number;
  };
  fileName: string;
}

function App() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<AnalysisResults | null>(null);
  const [targetRole, setTargetRole] = useState<string>('');

  const handleFileUpload = async (file: File) => {
    setIsAnalyzing(true);
    
    // Simulate analysis delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Mock analysis results
    const mockResults: AnalysisResults = {
      score: Math.floor(Math.random() * 40) + 60,
      breakdown: {
        keywords: Math.floor(Math.random() * 30) + 70,
        formatting: Math.floor(Math.random() * 20) + 80,
        experience: Math.floor(Math.random() * 25) + 65,
        skills: Math.floor(Math.random() * 35) + 60
      },
      fileName: file.name
    };
    
    setResults(mockResults);
    setIsAnalyzing(false);
  };

  const handleRoleAnalysis = (role: string) => {
    setTargetRole(role);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-full">
              <FileText className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            Resume Analyzer
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get instant ATS scoring, role analysis, and personalized job recommendations
          </p>
        </div>

        {!results ? (
          <div className="max-w-4xl mx-auto">
            <FileUpload onFileUpload={handleFileUpload} isAnalyzing={isAnalyzing} />
            
            {!isAnalyzing && (
              <div className="mt-12 grid md:grid-cols-3 gap-6 text-center">
                <div className="p-6">
                  <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sparkles className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-800 mb-2">ATS Score</h3>
                  <p className="text-gray-600">Get detailed analysis of how ATS systems will rate your resume</p>
                </div>
                
                <div className="p-6">
                  <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <FileText className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-800 mb-2">Role Analysis</h3>
                  <p className="text-gray-600">Understand skill requirements and get personalized recommendations</p>
                </div>
                
                <div className="p-6">
                  <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sparkles className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="font-semibold text-gray-800 mb-2">Job Matching</h3>
                  <p className="text-gray-600">Discover relevant job opportunities tailored to your profile</p>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="max-w-6xl mx-auto">
            <div className="mb-8 text-center">
              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                Analysis Complete!
              </h2>
              <p className="text-gray-600">
                Results for: <span className="font-medium">{results.fileName}</span>
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <ATSScore score={results.score} breakdown={results.breakdown} />
              </div>
              
              <div className="lg:col-span-2">
                <ResultsTabs onRoleAnalysis={handleRoleAnalysis} />
              </div>
            </div>

            <div className="mt-8 text-center">
              <button
                onClick={() => {
                  setResults(null);
                  setTargetRole('');
                }}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200"
              >
                Analyze Another Resume
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;